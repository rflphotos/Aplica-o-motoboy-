# Controle Motoboy — Android

Projeto Android nativo inicial, com banco SQLite local. Os lançamentos funcionam sem internet.

## O que já está incluído
- Registro de quantidade de entregas e valor total recebido.
- Registro de outros ganhos.
- Despesas por categoria: gasolina, refeição, manutenção, óleo/peças, pneu, documentos e outros.
- Resumo do mês atual: ganhos, despesas, saldo líquido, total de entregas e média recebida por entrega.
- Histórico dos lançamentos; toque e segure em um lançamento para excluí-lo.
- Banco de dados SQLite no próprio aparelho.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `controle-motoboy` no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitada.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O Android Studio mostrará o caminho do APK gerado. Para instalar no telefone, transfira o APK e autorize a instalação dessa fonte quando o Android solicitar.

Configuração: `applicationId` br.com.controlemotoboy, Android mínimo 6.0 (API 23).

## Observações
- Esta versão guarda os dados somente no aparelho. Desinstalar o app ou limpar os dados pode apagar os registros.
- Não há sincronização em nuvem nesta versão.
- Os valores são informados como total recebido no lançamento de entregas; o app calcula a média por entrega.
