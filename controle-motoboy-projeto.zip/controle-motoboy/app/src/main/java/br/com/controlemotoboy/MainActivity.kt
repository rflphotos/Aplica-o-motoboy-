package br.com.controlemotoboy

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale

private val pt = Locale("pt", "BR")
private fun money(value: Double): String = NumberFormat.getCurrencyInstance(pt).format(value)
private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun displayDate(raw: String): String = try {
    SimpleDateFormat("dd/MM/yyyy", pt).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(raw)!!)
} catch (_: Exception) { raw }
private fun parseMoney(raw: String): Double? = try {
    val cleaned = raw.trim().replace("R$", "").replace(" ", "")
    if (cleaned.contains(',')) cleaned.replace(".", "").replace(',', '.').toDouble() else cleaned.toDouble()
} catch (_: Exception) { null }

class EntriesDb(context: android.content.Context) : SQLiteOpenHelper(context, "controle_motoboy.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE entries (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, category TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0, amount REAL NOT NULL, date TEXT NOT NULL, note TEXT NOT NULL DEFAULT '')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(kind: String, category: String, quantity: Int, amount: Double, date: String, note: String) {
        val v = ContentValues().apply {
            put("kind", kind); put("category", category); put("quantity", quantity)
            put("amount", amount); put("date", date); put("note", note)
        }
        writableDatabase.insert("entries", null, v)
    }
    data class Entry(val id: Long, val kind: String, val category: String, val quantity: Int, val amount: Double, val date: String, val note: String)
    fun all(): List<Entry> {
        val result = mutableListOf<Entry>()
        readableDatabase.rawQuery("SELECT id,kind,category,quantity,amount,date,note FROM entries ORDER BY date DESC,id DESC", null).use { c ->
            while (c.moveToNext()) result.add(Entry(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getDouble(4), c.getString(5), c.getString(6)))
        }
        return result
    }
    fun delete(id: Long) { writableDatabase.delete("entries", "id=?", arrayOf(id.toString())) }
}

class MainActivity : Activity() {
    private lateinit var db: EntriesDb
    private lateinit var root: LinearLayout
    private lateinit var summary: LinearLayout
    private lateinit var history: LinearLayout
    private val green = 0xFF167D59.toInt()
    private val dark = 0xFF12382D.toInt()
    private val muted = 0xFF66736D.toInt()
    private val currency get() = NumberFormat.getCurrencyInstance(pt)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = EntriesDb(this)
        buildScreen()
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 16f, color: Int = 0xFF18231E.toInt(), bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(green)
        setPadding(dp(8), dp(5), dp(8), dp(5)); setOnClickListener { onClick() }
    }
    private fun buildScreen() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(24)); setBackgroundColor(0xFFF4F7F5.toInt()) }
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); setBackgroundColor(dark) }
        header.addView(text("🏍️  CONTROLE MOTOBOY", 20f, 0xFFFFFFFF.toInt(), true))
        header.addView(text("Seu financeiro de entregas, sem complicação", 13f, 0xFFD2E4DA.toInt()))
        root.addView(header)
        root.addView(space(12))
        summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(summary)
        root.addView(space(12))
        root.addView(text("LANÇAR MOVIMENTAÇÃO", 13f, muted, true))
        root.addView(space(6))
        root.addView(button("＋  Registrar entregas", ::showDeliveryDialog))
        root.addView(space(6))
        root.addView(button("＋  Registrar outro ganho", ::showIncomeDialog))
        root.addView(space(6))
        root.addView(button("－  Registrar despesa", ::showExpenseDialog))
        root.addView(space(18))
        root.addView(text("HISTÓRICO RECENTE", 13f, muted, true))
        root.addView(space(6))
        history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(history)
        root.addView(space(12))
        root.addView(text("Os registros ficam salvos neste aparelho. Faça cópias de segurança do celular para evitar perder os dados.", 12f, muted))
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); setBackgroundColor(0xFFFFFFFF.toInt())
    }
    private fun refresh() {
        val entries = db.all()
        val month = today().substring(0, 7)
        val current = entries.filter { it.date.startsWith(month) }
        val dayEntries = entries.filter { it.date == today() }
        val calendar = Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        }
        val weekStart = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(calendar.time)
        val weekEntries = entries.filter { it.date >= weekStart && it.date <= today() }
        val deliveries = current.filter { it.kind == "delivery" }
        val deliveryCount = deliveries.sumOf { it.quantity }
        val deliveryIncome = deliveries.sumOf { it.amount }
        val otherIncome = current.filter { it.kind == "income" }.sumOf { it.amount }
        val expenses = current.filter { it.kind == "expense" }.sumOf { it.amount }
        val totalIncome = deliveryIncome + otherIncome
        val net = totalIncome - expenses

        summary.removeAllViews()
        val hero = card().apply { setBackgroundColor(dark) }
        hero.addView(text("SALDO LÍQUIDO DO MÊS", 12f, 0xFFD2E4DA.toInt(), true))
        hero.addView(text(money(net), 28f, 0xFFFFFFFF.toInt(), true))
        hero.addView(text("Ganhos ${money(totalIncome)}   •   Despesas ${money(expenses)}", 13f, 0xFFD2E4DA.toInt()))
        summary.addView(hero)
        summary.addView(space(8))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(statCard("ENTREGAS", deliveryCount.toString()), LinearLayout.LayoutParams(0, -2, 1f))
        val avg = if (deliveryCount > 0) deliveryIncome / deliveryCount else 0.0
        stats.addView(statCard("MÉDIA / ENTREGA", money(avg)), LinearLayout.LayoutParams(0, -2, 1f))
        summary.addView(stats)
        summary.addView(space(10))
        summary.addView(text("FECHAMENTO POR PERÍODO", 12f, muted, true))
        summary.addView(space(5))
        summary.addView(periodCard("HOJE", dayEntries))
        summary.addView(space(5))
        summary.addView(periodCard("ESTA SEMANA", weekEntries))
        summary.addView(space(5))
        summary.addView(periodCard("ESTE MÊS", current))
        summary.addView(space(4))

        history.removeAllViews()
        if (entries.isEmpty()) {
            history.addView(card().apply { addView(text("Nenhum lançamento ainda. Comece registrando suas entregas ou despesas.", 14f, muted)) })
        } else {
            entries.take(30).forEach { e ->
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(4), dp(10)); setBackgroundColor(0xFFFFFFFF.toInt()) }
                val detail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                val label = when (e.kind) { "delivery" -> "Entregas • ${e.quantity} entrega(s)"; "income" -> "Outro ganho • ${e.category}"; else -> "Despesa • ${e.category}" }
                detail.addView(text(label, 14f, 0xFF18231E.toInt(), true))
                detail.addView(text("${displayDate(e.date)}${if (e.note.isNotBlank()) " • ${e.note}" else ""}", 12f, muted))
                line.addView(detail, LinearLayout.LayoutParams(0, -2, 1f))
                val positive = e.kind != "expense"
                line.addView(text((if (positive) "+ " else "− ") + money(e.amount), 14f, if (positive) green else 0xFFB33B32.toInt(), true))
                line.setOnLongClickListener {
                    AlertDialog.Builder(this).setTitle("Excluir lançamento?").setMessage("${label} — ${money(e.amount)}")
                        .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ -> db.delete(e.id); refresh() }.show(); true
                }
                history.addView(line)
                val divider = View(this).apply { setBackgroundColor(0xFFE6ECE8.toInt()); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) }
                history.addView(divider)
            }
            history.addView(text("Dica: pressione e segure um lançamento para excluí-lo.", 11f, muted))
        }
    }
    private fun statCard(label: String, value: String): LinearLayout = card().apply {
        addView(text(label, 10f, muted, true)); addView(text(value, 17f, 0xFF18231E.toInt(), true))
    }
    private fun periodCard(label: String, items: List<EntriesDb.Entry>): LinearLayout {
        val gains = items.filter { it.kind != "expense" }.sumOf { it.amount }
        val costs = items.filter { it.kind == "expense" }.sumOf { it.amount }
        val balance = gains - costs
        return card().apply {
            orientation = LinearLayout.HORIZONTAL
            val left = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            left.addView(text(label, 11f, muted, true))
            left.addView(text("Entradas ${money(gains)}  •  Saídas ${money(costs)}", 12f, muted))
            addView(left, LinearLayout.LayoutParams(0, -2, 1f))
            addView(text(money(balance), 15f, if (balance >= 0) green else 0xFFB33B32.toInt(), true))
        }
    }
    private fun field(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint; setSingleLine(true); setText(value); textSize = 16f
    }
    private fun dateField(): EditText = field("Data (dd/MM/aaaa)", SimpleDateFormat("dd/MM/yyyy", pt).format(Date()))
    private fun readDate(raw: String): String? = try {
        val parsed = SimpleDateFormat("dd/MM/yyyy", pt).apply { isLenient = false }.parse(raw.trim())!!
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(parsed)
    } catch (_: Exception) { null }
    private fun formDialog(title: String, content: LinearLayout, save: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setView(content).setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar", null).create().also { dialog ->
                dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    try { save(); dialog.dismiss(); refresh() } catch (e: IllegalArgumentException) {
                        Toast.makeText(this, e.message ?: "Confira os dados.", Toast.LENGTH_LONG).show()
                    }
                } }
                dialog.show()
            }
    }
    private fun formContainer(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
    private fun addLabel(box: LinearLayout, label: String) { box.addView(text(label, 13f, muted, true)) }
    private fun showDeliveryDialog() {
        val box = formContainer()
        addLabel(box, "Quantidade de entregas")
        val qty = field("Ex.: 8"); qty.inputType = 2; box.addView(qty)
        addLabel(box, "Total recebido pelas entregas (R$)")
        val amount = field("Ex.: 96,00"); amount.inputType = 8194; box.addView(amount)
        addLabel(box, "Data")
        val date = dateField(); box.addView(date)
        addLabel(box, "Observação (opcional)")
        val note = field("Ex.: entregas do período da manhã"); box.addView(note)
        formDialog("Registrar entregas", box) {
            val q = qty.text.toString().toIntOrNull(); val a = parseMoney(amount.text.toString()); val d = readDate(date.text.toString())
            require(q != null && q > 0) { "Informe uma quantidade válida." }
            require(a != null && a > 0) { "Informe o valor total recebido." }
            require(d != null) { "Informe uma data válida." }
            db.add("delivery", "Entregas", q!!, a!!, d!!, note.text.toString().trim())
        }
    }
    private fun showIncomeDialog() {
        val box = formContainer()
        addLabel(box, "Descrição do ganho")
        val desc = field("Ex.: serviço extra, diária"); box.addView(desc)
        addLabel(box, "Valor recebido (R$)")
        val amount = field("Ex.: 50,00"); amount.inputType = 8194; box.addView(amount)
        addLabel(box, "Data")
        val date = dateField(); box.addView(date)
        formDialog("Registrar outro ganho", box) {
            val a = parseMoney(amount.text.toString()); val d = readDate(date.text.toString())
            require(desc.text.toString().trim().isNotEmpty()) { "Informe a descrição do ganho." }
            require(a != null && a > 0) { "Informe um valor válido." }; require(d != null) { "Informe uma data válida." }
            db.add("income", desc.text.toString().trim(), 0, a!!, d!!, "")
        }
    }
    private fun showExpenseDialog() {
        val box = formContainer()
        addLabel(box, "Categoria da despesa")
        val categories = arrayOf("Gasolina", "Refeição", "Manutenção", "Óleo e peças", "Pneu", "Documentos", "Outros")
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, categories) }
        box.addView(spinner)
        addLabel(box, "Valor gasto (R$)")
        val amount = field("Ex.: 35,00"); amount.inputType = 8194; box.addView(amount)
        addLabel(box, "Data")
        val date = dateField(); box.addView(date)
        addLabel(box, "Observação (opcional)")
        val note = field("Ex.: abastecimento completo"); box.addView(note)
        formDialog("Registrar despesa", box) {
            val a = parseMoney(amount.text.toString()); val d = readDate(date.text.toString())
            require(a != null && a > 0) { "Informe um valor válido." }; require(d != null) { "Informe uma data válida." }
            db.add("expense", spinner.selectedItem.toString(), 0, a!!, d!!, note.text.toString().trim())
        }
    }
}
